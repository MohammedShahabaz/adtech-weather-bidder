import React from 'react';
import './App.css';
import WeatherBidder from './components/WeatherComponent';

function App() {
  return (
    <div className="App">
      <WeatherBidder />
    </div>
  );
}

export default App;
