import React, { useState, useEffect } from 'react';
import axios from 'axios';

const WeatherBidder = () => {
  const [weather, setWeather] = useState(null);
  const [bidAdjustment, setBidAdjustment] = useState('Normal');

  useEffect(() => {
    const fetchWeather = async () => {
      try {
        const response = await axios.get('http://api.weatherapi.com/v1/current.json', {
          params: {
            key: '89bea6b137884ff2a69153356240608',
            q: 'London',
          },
        });
        const data = response.data;
        setWeather(data);
        adjustBid(data.current);
      } catch (error) {
        console.error('Error fetching the weather data', error);
      }
    };

    fetchWeather();
  }, []);

  const adjustBid = (currentWeather) => {
    const { temp_c, condition } = currentWeather;

    if (condition.text.toLowerCase().includes('sunny') && temp_c > 25) {
      setBidAdjustment('Increase by 20%');
    } else if (condition.text.toLowerCase().includes('rainy')) {
      setBidAdjustment('Decrease by 20%');
    } else {
      setBidAdjustment('Keep at normal level');
    }
  };

  return (
    <div>
      <h1>Weather Bid Adjustment</h1>
      {weather ? (
        <div>
          <p>Location: {weather.location.name}</p>
          <p>Temperature: {weather.current.temp_c}°C</p>
          <p>Condition: {weather.current.condition.text}</p>
          <p>Bid Adjustment: {bidAdjustment}</p>
        </div>
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
};

export default WeatherBidder;
